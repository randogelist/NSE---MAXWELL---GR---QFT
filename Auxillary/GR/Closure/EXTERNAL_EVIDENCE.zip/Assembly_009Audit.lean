import GRAssembly.HodgeBounds
set_option pp.universes false
#check @NSEGR.Assembly.poissonInverse_joint_smooth_global
#print axioms NSEGR.Assembly.poissonInverse_joint_smooth_global
#check @NSEGR.Assembly.poissonInverse_joint_smooth_on_open_slab
#print axioms NSEGR.Assembly.poissonInverse_joint_smooth_on_open_slab
#check @NSEGR.Assembly.scalarSpatialIterate
#print axioms NSEGR.Assembly.scalarSpatialIterate
#check @NSEGR.Assembly.scalarSpatialIterate_smooth
#print axioms NSEGR.Assembly.scalarSpatialIterate_smooth
#check @NSEGR.Assembly.scalarSpatialIterate_periodic
#print axioms NSEGR.Assembly.scalarSpatialIterate_periodic
#check @NSEGR.Assembly.scalarLift_scalarSpatialIterate
#print axioms NSEGR.Assembly.scalarLift_scalarSpatialIterate
#check @NSEGR.Assembly.scalar_integral_norm_le
#print axioms NSEGR.Assembly.scalar_integral_norm_le
#check @NSEGR.Assembly.scalar_fourierDecayConstant_eight_le
#print axioms NSEGR.Assembly.scalar_fourierDecayConstant_eight_le
#check @NSEGR.Assembly.scalarCoeff_norm_le_eight
#print axioms NSEGR.Assembly.scalarCoeff_norm_le_eight
#check @NSEGR.Assembly.poissonInverseFixedLossConstant
#print axioms NSEGR.Assembly.poissonInverseFixedLossConstant
#check @NSEGR.Assembly.poissonInverseFixedLossConstant_pos
#print axioms NSEGR.Assembly.poissonInverseFixedLossConstant_pos
#check @NSEGR.Assembly.poissonInverse_norm_le_eight
#print axioms NSEGR.Assembly.poissonInverse_norm_le_eight

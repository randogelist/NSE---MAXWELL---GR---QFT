import GRAssembly.NativeGluingTranslation
set_option pp.universes false
#check @NSEGR.Assembly.spatialPeriodic_sub_integer
#print axioms NSEGR.Assembly.spatialPeriodic_sub_integer
#check @NSEGR.Assembly.fderiv_spatialPeriodic_sub_integer
#print axioms NSEGR.Assembly.fderiv_spatialPeriodic_sub_integer
#check @NSEGR.Assembly.scalarCompletionUpper_spatial_sub
#print axioms NSEGR.Assembly.scalarCompletionUpper_spatial_sub
#check @NSEGR.Assembly.conservedSourceUpper_periodic_sub
#print axioms NSEGR.Assembly.conservedSourceUpper_periodic_sub
#check @NSEGR.Assembly.completedBoundary_spatial_sub
#print axioms NSEGR.Assembly.completedBoundary_spatial_sub
#check @NSEGR.Assembly.scalarCompletionUpper_joint_congr
#print axioms NSEGR.Assembly.scalarCompletionUpper_joint_congr
#check @NSEGR.Assembly.completedBoundary_joint_congr
#print axioms NSEGR.Assembly.completedBoundary_joint_congr
#check @NSEGR.Assembly.boundaryHamiltonian_joint_congr
#print axioms NSEGR.Assembly.boundaryHamiltonian_joint_congr
#check @NSEGR.Assembly.bulkPartial_comp_sub
#print axioms NSEGR.Assembly.bulkPartial_comp_sub
#check @NSEGR.Assembly.christoffel_comp_sub
#print axioms NSEGR.Assembly.christoffel_comp_sub
#check @NSEGR.Assembly.ricci_comp_sub
#print axioms NSEGR.Assembly.ricci_comp_sub
#check @NSEGR.Assembly.bulkPoint_sub_spatial
#print axioms NSEGR.Assembly.bulkPoint_sub_spatial
#check @NSEGR.Assembly.boundaryK_comp_spatial_sub
#print axioms NSEGR.Assembly.boundaryK_comp_spatial_sub

import GRAssembly.BoundaryConstraints
set_option pp.universes false
#check @NSEGR.Assembly.metricTangentialBlock
#print axioms NSEGR.Assembly.metricTangentialBlock
#check @NSEGR.Assembly.bulkCollar_isOpen
#print axioms NSEGR.Assembly.bulkCollar_isOpen
#check @NSEGR.Assembly.boundaryPoint_mem_collar
#print axioms NSEGR.Assembly.boundaryPoint_mem_collar
#check @NSEGR.Assembly.boundary_time_eventually
#print axioms NSEGR.Assembly.boundary_time_eventually
#check @NSEGR.Assembly.gaussianVacuum_block_analytic
#print axioms NSEGR.Assembly.gaussianVacuum_block_analytic
#check @NSEGR.Assembly.gaussianVacuum_eq_gaussian
#print axioms NSEGR.Assembly.gaussianVacuum_eq_gaussian
#check @NSEGR.Assembly.gaussianVacuum_eq_gaussian_germ
#print axioms NSEGR.Assembly.gaussianVacuum_eq_gaussian_germ
#check @NSEGR.Assembly.gaussianVacuum_block_unit
#print axioms NSEGR.Assembly.gaussianVacuum_block_unit
#check @NSEGR.Assembly.gaussianVacuum_block_unit_germ
#print axioms NSEGR.Assembly.gaussianVacuum_block_unit_germ
#check @NSEGR.Assembly.christoffel_congr_germ
#print axioms NSEGR.Assembly.christoffel_congr_germ
#check @NSEGR.Assembly.ricci_congr_germ
#print axioms NSEGR.Assembly.ricci_congr_germ
#check @NSEGR.Assembly.gaussianVacuum_block_vacuum
#print axioms NSEGR.Assembly.gaussianVacuum_block_vacuum
#check @NSEGR.Assembly.boundaryK_eq_block
#print axioms NSEGR.Assembly.boundaryK_eq_block
#check @NSEGR.Assembly.gaussianVacuum_boundary_analytic
#print axioms NSEGR.Assembly.gaussianVacuum_boundary_analytic
#check @NSEGR.Assembly.gaussianVacuum_boundary_symmetric
#print axioms NSEGR.Assembly.gaussianVacuum_boundary_symmetric
#check @NSEGR.Assembly.gaussianVacuum_boundary_periodic
#print axioms NSEGR.Assembly.gaussianVacuum_boundary_periodic
#check @NSEGR.Assembly.gaussianVacuum_block_flat
#print axioms NSEGR.Assembly.gaussianVacuum_block_flat
#check @NSEGR.Assembly.gaussianVacuum_block_tangent_zero
#print axioms NSEGR.Assembly.gaussianVacuum_block_tangent_zero
#check @NSEGR.Assembly.gaussianVacuum_connection_zero
#print axioms NSEGR.Assembly.gaussianVacuum_connection_zero
#check @NSEGR.Assembly.gaussianVacuum_connection_tangent_zero
#print axioms NSEGR.Assembly.gaussianVacuum_connection_tangent_zero
#check @NSEGR.Assembly.gaussianVacuum_boundary_hamiltonian
#print axioms NSEGR.Assembly.gaussianVacuum_boundary_hamiltonian
#check @NSEGR.Assembly.gaussianVacuum_shape_tangent
#print axioms NSEGR.Assembly.gaussianVacuum_shape_tangent
#check @NSEGR.Assembly.gaussianVacuum_boundary_codazzi
#print axioms NSEGR.Assembly.gaussianVacuum_boundary_codazzi
#check @NSEGR.Assembly.gaussianVacuum_boundaryAdmissible
#print axioms NSEGR.Assembly.gaussianVacuum_boundaryAdmissible

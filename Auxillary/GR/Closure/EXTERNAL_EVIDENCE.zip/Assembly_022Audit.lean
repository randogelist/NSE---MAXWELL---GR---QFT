import GRAssembly.NativeCompletionCalculus
set_option pp.universes false
#check @NSEGR.Assembly.jointSpace_isotropic_sum
#print axioms NSEGR.Assembly.jointSpace_isotropic_sum
#check @NSEGR.Assembly.jointSpace_hessian_divergence
#print axioms NSEGR.Assembly.jointSpace_hessian_divergence
#check @NSEGR.Assembly.scalarCompletionUpper_conserved
#print axioms NSEGR.Assembly.scalarCompletionUpper_conserved
#check @NSEGR.Assembly.analyticAt_conservedSourceUpper_entry
#print axioms NSEGR.Assembly.analyticAt_conservedSourceUpper_entry
#check @NSEGR.Assembly.analyticAt_scalarCompletionUpper_entry
#print axioms NSEGR.Assembly.analyticAt_scalarCompletionUpper_entry
#check @NSEGR.Assembly.analyticAt_completedBoundary
#print axioms NSEGR.Assembly.analyticAt_completedBoundary
#check @NSEGR.Assembly.boundaryPartial_add_native
#print axioms NSEGR.Assembly.boundaryPartial_add_native
#check @NSEGR.Assembly.boundaryPartial_const_mul_native
#print axioms NSEGR.Assembly.boundaryPartial_const_mul_native
#check @NSEGR.Assembly.traceReverse_lower_codazzi
#print axioms NSEGR.Assembly.traceReverse_lower_codazzi
#check @NSEGR.Assembly.completedBoundary_codazzi
#print axioms NSEGR.Assembly.completedBoundary_codazzi
#check @NSEGR.Assembly.completedBoundary_symmetric
#print axioms NSEGR.Assembly.completedBoundary_symmetric
#check @NSEGR.Assembly.scalarLocalTimeDerivative_periodic_on_interval
#print axioms NSEGR.Assembly.scalarLocalTimeDerivative_periodic_on_interval
#check @NSEGR.Assembly.scalarHessian_periodic_native
#print axioms NSEGR.Assembly.scalarHessian_periodic_native
#check @NSEGR.Assembly.completedBoundary_periodic
#print axioms NSEGR.Assembly.completedBoundary_periodic
#check @NSEGR.Assembly.completedBoundary_admissible
#print axioms NSEGR.Assembly.completedBoundary_admissible

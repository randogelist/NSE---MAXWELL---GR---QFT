import GRAssembly.NativeGluingAtlas
set_option pp.universes false
#check @NSEGR.Assembly.spatialTranslate
#print axioms NSEGR.Assembly.spatialTranslate
#check @NSEGR.Assembly.gluingSpatialBox
#print axioms NSEGR.Assembly.gluingSpatialBox
#check @NSEGR.Assembly.gluingSpatialBox_isOpen
#print axioms NSEGR.Assembly.gluingSpatialBox_isOpen
#check @NSEGR.Assembly.unitCube_subset_gluingSpatialBox
#print axioms NSEGR.Assembly.unitCube_subset_gluingSpatialBox
#check @NSEGR.Assembly.periodic_law_of_unique_local_germs
#print axioms NSEGR.Assembly.periodic_law_of_unique_local_germs
#check @NSEGR.Assembly.positive_timeInterval_subset
#print axioms NSEGR.Assembly.positive_timeInterval_subset

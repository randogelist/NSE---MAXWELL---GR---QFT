import GRAssembly.NativeConservation
set_option pp.universes false
#check @NSEGR.Assembly.boundaryAdmissible_entry_analytic
#print axioms NSEGR.Assembly.boundaryAdmissible_entry_analytic
#check @NSEGR.Assembly.boundaryAdmissible_beta_analytic
#print axioms NSEGR.Assembly.boundaryAdmissible_beta_analytic
#check @NSEGR.Assembly.boundaryAdmissible_raw_analytic
#print axioms NSEGR.Assembly.boundaryAdmissible_raw_analytic
#check @NSEGR.Assembly.boundaryAdmissible_beta_periodic
#print axioms NSEGR.Assembly.boundaryAdmissible_beta_periodic
#check @NSEGR.Assembly.boundaryAdmissible_raw_periodic
#print axioms NSEGR.Assembly.boundaryAdmissible_raw_periodic
#check @NSEGR.Assembly.boundaryAdmissible_raw_smooth
#print axioms NSEGR.Assembly.boundaryAdmissible_raw_smooth
#check @NSEGR.Assembly.boundaryAdmissible_beta_time
#print axioms NSEGR.Assembly.boundaryAdmissible_beta_time
#check @NSEGR.Assembly.boundaryAdmissible_beta_mean
#print axioms NSEGR.Assembly.boundaryAdmissible_beta_mean
#check @NSEGR.Assembly.boundaryAdmissible_rawVelocity_time
#print axioms NSEGR.Assembly.boundaryAdmissible_rawVelocity_time

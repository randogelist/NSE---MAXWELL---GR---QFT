import GRAssembly.NativeCompletion
set_option pp.universes false
#check @NSEGR.Assembly.poissonInverse_sub_native
#print axioms NSEGR.Assembly.poissonInverse_sub_native
#check @NSEGR.Assembly.leray_sub_native
#print axioms NSEGR.Assembly.leray_sub_native
#check @NSEGR.Assembly.completedBoundary_velocity_recovery
#print axioms NSEGR.Assembly.completedBoundary_velocity_recovery
#check @NSEGR.Assembly.completedBoundary_potential_recovery
#print axioms NSEGR.Assembly.completedBoundary_potential_recovery
#check @NSEGR.Assembly.completedBoundary_stress_zero
#print axioms NSEGR.Assembly.completedBoundary_stress_zero
#check @NSEGR.Assembly.completedBoundary_pressure_recovery
#print axioms NSEGR.Assembly.completedBoundary_pressure_recovery
#check @NSEGR.Assembly.localNSE_restrict_native
#print axioms NSEGR.Assembly.localNSE_restrict_native
#check @NSEGR.Assembly.scalarBoundaryCompletionLaws_of_literatureCK
#print axioms NSEGR.Assembly.scalarBoundaryCompletionLaws_of_literatureCK

import GRAssembly.AnalyticHodgeTaylor
set_option pp.universes false
#check @NSEGR.Assembly.factorialTaylor_remainder_bound
#print axioms NSEGR.Assembly.factorialTaylor_remainder_bound
#check @NSEGR.Assembly.analyticAt_of_iteratedFDeriv_bound
#print axioms NSEGR.Assembly.analyticAt_of_iteratedFDeriv_bound

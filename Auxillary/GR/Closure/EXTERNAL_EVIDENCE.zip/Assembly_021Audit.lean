import GRAssembly.NativeCalculus
set_option pp.universes false
#check @NSEGR.Assembly.tensor4Entry
#print axioms NSEGR.Assembly.tensor4Entry
#check @NSEGR.Assembly.analyticAt_tensor4_entry
#print axioms NSEGR.Assembly.analyticAt_tensor4_entry
#check @NSEGR.Assembly.analyticAt_tensor4_of_entries
#print axioms NSEGR.Assembly.analyticAt_tensor4_of_entries
#check @NSEGR.Assembly.analyticAt_vec_of_components
#print axioms NSEGR.Assembly.analyticAt_vec_of_components
#check @NSEGR.Assembly.analyticOnNhd_slab_contDiffOn
#print axioms NSEGR.Assembly.analyticOnNhd_slab_contDiffOn
#check @NSEGR.Assembly.analyticOnNhd_slab_slice_smooth
#print axioms NSEGR.Assembly.analyticOnNhd_slab_slice_smooth
#check @NSEGR.Assembly.jointSpace_jointSpace
#print axioms NSEGR.Assembly.jointSpace_jointSpace
#check @NSEGR.Assembly.jointTime_sum
#print axioms NSEGR.Assembly.jointTime_sum
#check @NSEGR.Assembly.jointSpace_sum
#print axioms NSEGR.Assembly.jointSpace_sum
#check @NSEGR.Assembly.jointTime_add
#print axioms NSEGR.Assembly.jointTime_add
#check @NSEGR.Assembly.jointSpace_add
#print axioms NSEGR.Assembly.jointSpace_add
#check @NSEGR.Assembly.jointSpace_sub
#print axioms NSEGR.Assembly.jointSpace_sub
#check @NSEGR.Assembly.analyticAt_gradient_joint
#print axioms NSEGR.Assembly.analyticAt_gradient_joint
#check @NSEGR.Assembly.analyticAt_boundaryBeta
#print axioms NSEGR.Assembly.analyticAt_boundaryBeta
#check @NSEGR.Assembly.analyticAt_boundaryRawVelocity
#print axioms NSEGR.Assembly.analyticAt_boundaryRawVelocity
#check @NSEGR.Assembly.scalar_time_laplacian_commute
#print axioms NSEGR.Assembly.scalar_time_laplacian_commute
#check @NSEGR.Assembly.scalar_time_gradient_commute
#print axioms NSEGR.Assembly.scalar_time_gradient_commute
#check @NSEGR.Assembly.scalarMean_sub_const_native
#print axioms NSEGR.Assembly.scalarMean_sub_const_native
#check @NSEGR.Assembly.poissonInverse_neg_native
#print axioms NSEGR.Assembly.poissonInverse_neg_native

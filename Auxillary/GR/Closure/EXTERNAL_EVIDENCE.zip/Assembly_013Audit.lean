import GRAssembly.BoundaryConstraintsJets
set_option pp.universes false
#check @NSEGR.Assembly.matrixEntryCLM
#print axioms NSEGR.Assembly.matrixEntryCLM
#check @NSEGR.Assembly.analyticAt_matrix_entry
#print axioms NSEGR.Assembly.analyticAt_matrix_entry
#check @NSEGR.Assembly.analyticAt_matrix_of_entries
#print axioms NSEGR.Assembly.analyticAt_matrix_of_entries
#check @NSEGR.Assembly.matrix_entry_fderiv
#print axioms NSEGR.Assembly.matrix_entry_fderiv
#check @NSEGR.Assembly.boundaryEmbed
#print axioms NSEGR.Assembly.boundaryEmbed
#check @NSEGR.Assembly.boundaryEmbed_coe
#print axioms NSEGR.Assembly.boundaryEmbed_coe
#check @NSEGR.Assembly.boundaryEmbed_time
#print axioms NSEGR.Assembly.boundaryEmbed_time
#check @NSEGR.Assembly.boundaryEmbed_space
#print axioms NSEGR.Assembly.boundaryEmbed_space
#check @NSEGR.Assembly.analyticAt_bulkPartial
#print axioms NSEGR.Assembly.analyticAt_bulkPartial
#check @NSEGR.Assembly.boundaryPartial_restrict
#print axioms NSEGR.Assembly.boundaryPartial_restrict
#check @NSEGR.Assembly.boundaryPartial_congr
#print axioms NSEGR.Assembly.boundaryPartial_congr
#check @NSEGR.Assembly.bulkPartial_tangent_zero
#print axioms NSEGR.Assembly.bulkPartial_tangent_zero
#check @NSEGR.Assembly.bulkPartial_radial_restrict
#print axioms NSEGR.Assembly.bulkPartial_radial_restrict
#check @NSEGR.Assembly.analyticAt_matrix_inverse
#print axioms NSEGR.Assembly.analyticAt_matrix_inverse
#check @NSEGR.Assembly.bulkPartial_inverse
#print axioms NSEGR.Assembly.bulkPartial_inverse
#check @NSEGR.Assembly.analyticAt_gaussianSecondForm
#print axioms NSEGR.Assembly.analyticAt_gaussianSecondForm
#check @NSEGR.Assembly.analyticAt_gaussianShape
#print axioms NSEGR.Assembly.analyticAt_gaussianShape
#check @NSEGR.Assembly.analyticAt_gaussianTangentialChristoffel
#print axioms NSEGR.Assembly.analyticAt_gaussianTangentialChristoffel
#check @NSEGR.Assembly.gaussianShape_at_flat
#print axioms NSEGR.Assembly.gaussianShape_at_flat
#check @NSEGR.Assembly.bulkPartial_inverse_at_flat
#print axioms NSEGR.Assembly.bulkPartial_inverse_at_flat

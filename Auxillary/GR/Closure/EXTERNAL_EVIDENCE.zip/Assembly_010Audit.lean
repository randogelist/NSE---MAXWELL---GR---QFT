import GRAssembly.HodgeCommutation
set_option pp.universes false
#check @NSEGR.Assembly.poissonInverse_const_mul
#print axioms NSEGR.Assembly.poissonInverse_const_mul
#check @NSEGR.Assembly.poissonInverse_add
#print axioms NSEGR.Assembly.poissonInverse_add
#check @NSEGR.Assembly.jointLinear_coordinate_expansion
#print axioms NSEGR.Assembly.jointLinear_coordinate_expansion
#check @NSEGR.Assembly.joint_fderiv_time
#print axioms NSEGR.Assembly.joint_fderiv_time
#check @NSEGR.Assembly.joint_fderiv_space
#print axioms NSEGR.Assembly.joint_fderiv_space
#check @NSEGR.Assembly.joint_fderiv_smooth
#print axioms NSEGR.Assembly.joint_fderiv_smooth
#check @NSEGR.Assembly.joint_fderiv_periodic
#print axioms NSEGR.Assembly.joint_fderiv_periodic
#check @NSEGR.Assembly.poissonInverse_fderiv_commute_global
#print axioms NSEGR.Assembly.poissonInverse_fderiv_commute_global
#check @NSEGR.Assembly.iteratedFDeriv_apply_smooth_global
#print axioms NSEGR.Assembly.iteratedFDeriv_apply_smooth_global
#check @NSEGR.Assembly.iteratedFDeriv_slice_periodic_global
#print axioms NSEGR.Assembly.iteratedFDeriv_slice_periodic_global
#check @NSEGR.Assembly.poissonInverse_iteratedFDeriv_commute_global
#print axioms NSEGR.Assembly.poissonInverse_iteratedFDeriv_commute_global
#check @NSEGR.Assembly.fullSlice_iteratedFDeriv_eq
#print axioms NSEGR.Assembly.fullSlice_iteratedFDeriv_eq
#check @NSEGR.Assembly.iteratedFDeriv_slice_smooth_periodic
#print axioms NSEGR.Assembly.iteratedFDeriv_slice_smooth_periodic
#check @NSEGR.Assembly.poissonInverse_iteratedFDeriv_commute
#print axioms NSEGR.Assembly.poissonInverse_iteratedFDeriv_commute
#check @NSEGR.Assembly.prependSpatialDirections
#print axioms NSEGR.Assembly.prependSpatialDirections
#check @NSEGR.Assembly.scalarSpatialIterate_iteratedFDeriv_global
#print axioms NSEGR.Assembly.scalarSpatialIterate_iteratedFDeriv_global
#check @NSEGR.Assembly.prependSpatialDirections_norm_prod
#print axioms NSEGR.Assembly.prependSpatialDirections_norm_prod
#check @NSEGR.Assembly.scalarSpatialIterate_iteratedFDeriv
#print axioms NSEGR.Assembly.scalarSpatialIterate_iteratedFDeriv

import GRAssembly.BoundaryConstraintsGeometry
set_option pp.universes false
#check @NSEGR.Assembly.bulkPartial_mul
#print axioms NSEGR.Assembly.bulkPartial_mul
#check @NSEGR.Assembly.bulkPartial_sum
#print axioms NSEGR.Assembly.bulkPartial_sum
#check @NSEGR.Assembly.bulkPartial_shape_at_flat
#print axioms NSEGR.Assembly.bulkPartial_shape_at_flat
#check @NSEGR.Assembly.gaussian_normal_flat
#print axioms NSEGR.Assembly.gaussian_normal_flat
#check @NSEGR.Assembly.gaussian_tangential_flat
#print axioms NSEGR.Assembly.gaussian_tangential_flat
#check @NSEGR.Assembly.gaussian_hamiltonian_flat
#print axioms NSEGR.Assembly.gaussian_hamiltonian_flat
#check @NSEGR.Assembly.boundaryDirection
#print axioms NSEGR.Assembly.boundaryDirection
#check @NSEGR.Assembly.boundaryPartial_eq_joint
#print axioms NSEGR.Assembly.boundaryPartial_eq_joint
#check @NSEGR.Assembly.boundaryPartial_sub
#print axioms NSEGR.Assembly.boundaryPartial_sub
#check @NSEGR.Assembly.boundaryPartial_const_mul
#print axioms NSEGR.Assembly.boundaryPartial_const_mul
#check @NSEGR.Assembly.boundaryPartial_sum
#print axioms NSEGR.Assembly.boundaryPartial_sum
#check @NSEGR.Assembly.lorentzTrace4_eq_sum
#print axioms NSEGR.Assembly.lorentzTrace4_eq_sum
#check @NSEGR.Assembly.analyticAt_boundaryTrace
#print axioms NSEGR.Assembly.analyticAt_boundaryTrace
#check @NSEGR.Assembly.boundaryCodazzi_expanded
#print axioms NSEGR.Assembly.boundaryCodazzi_expanded

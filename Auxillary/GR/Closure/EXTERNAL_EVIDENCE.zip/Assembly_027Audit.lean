import GRAssembly.NativeGluingScalar
set_option pp.universes false
#check @NSEGR.Assembly.scalarNormalGerm_of_hamiltonian_nativeGluing
#print axioms NSEGR.Assembly.scalarNormalGerm_of_hamiltonian_nativeGluing
#check @NSEGR.Assembly.ScalarGluingLaw
#print axioms NSEGR.Assembly.ScalarGluingLaw
#check @NSEGR.Assembly.ScalarGluingLaw.congr
#print axioms NSEGR.Assembly.ScalarGluingLaw.congr
#check @NSEGR.Assembly.ScalarGluingLaw.translate
#print axioms NSEGR.Assembly.ScalarGluingLaw.translate
#check @NSEGR.Assembly.scalarGluingLaw_germ_of_normal
#print axioms NSEGR.Assembly.scalarGluingLaw_germ_of_normal
#check @NSEGR.Assembly.scalarNormalGerm_of_gluingLaw
#print axioms NSEGR.Assembly.scalarNormalGerm_of_gluingLaw
#check @NSEGR.Assembly.scalar_periodic_cylinder_of_literatureCK
#print axioms NSEGR.Assembly.scalar_periodic_cylinder_of_literatureCK
#check @NSEGR.Assembly.scalarLaplacian_spatial_sub
#print axioms NSEGR.Assembly.scalarLaplacian_spatial_sub
#check @NSEGR.Assembly.scalarLaplacian_periodic_nativeGluing
#print axioms NSEGR.Assembly.scalarLaplacian_periodic_nativeGluing
#check @NSEGR.Assembly.scalar_periodic_normal_cylinder_of_literatureCK
#print axioms NSEGR.Assembly.scalar_periodic_normal_cylinder_of_literatureCK

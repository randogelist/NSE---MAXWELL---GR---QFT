import GRAssembly.NativeInverseCanonical
set_option pp.universes false
#check @NSEGR.Assembly.canonical_scalarNormalGerm
#print axioms NSEGR.Assembly.canonical_scalarNormalGerm
#check @NSEGR.Assembly.canonical_chosenBoundary_eventually
#print axioms NSEGR.Assembly.canonical_chosenBoundary_eventually
#check @NSEGR.Assembly.lift_decode_of_literature
#print axioms NSEGR.Assembly.lift_decode_of_literature
#check @NSEGR.Assembly.germInverseLaws_of_literature
#print axioms NSEGR.Assembly.germInverseLaws_of_literature

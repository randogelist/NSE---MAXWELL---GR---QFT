import GRAssembly.NativeGluingGaussianCoordinates
set_option pp.universes false
#check @NSEGR.Assembly.GaussianJoint
#print axioms NSEGR.Assembly.GaussianJoint
#check @NSEGR.Assembly.bulkFromJoint
#print axioms NSEGR.Assembly.bulkFromJoint
#check @NSEGR.Assembly.jointFromBulk
#print axioms NSEGR.Assembly.jointFromBulk
#check @NSEGR.Assembly.jointMetric
#print axioms NSEGR.Assembly.jointMetric
#check @NSEGR.Assembly.metricOfJoint
#print axioms NSEGR.Assembly.metricOfJoint
#check @NSEGR.Assembly.metricOfJoint_germ
#print axioms NSEGR.Assembly.metricOfJoint_germ
#check @NSEGR.Assembly.jointMetric_germ
#print axioms NSEGR.Assembly.jointMetric_germ
#check @NSEGR.Assembly.metricOfJoint_translate
#print axioms NSEGR.Assembly.metricOfJoint_translate
#check @NSEGR.Assembly.bulkPartial_metric_germ
#print axioms NSEGR.Assembly.bulkPartial_metric_germ
#check @NSEGR.Assembly.christoffel_metric_germ
#print axioms NSEGR.Assembly.christoffel_metric_germ
#check @NSEGR.Assembly.ricci_metric_germ
#print axioms NSEGR.Assembly.ricci_metric_germ
#check @NSEGR.Assembly.boundaryK_metric_germ
#print axioms NSEGR.Assembly.boundaryK_metric_germ
#check @NSEGR.Assembly.gluingMetricEntry
#print axioms NSEGR.Assembly.gluingMetricEntry
#check @NSEGR.Assembly.near_eta4_of_gaussianGerm
#print axioms NSEGR.Assembly.near_eta4_of_gaussianGerm

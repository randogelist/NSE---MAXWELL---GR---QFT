import GRAssembly.NativeGluingGaussian
set_option pp.universes false
#check @NSEGR.Assembly.GaussianGluingLaw
#print axioms NSEGR.Assembly.GaussianGluingLaw
#check @NSEGR.Assembly.GaussianGluingLaw.congr
#print axioms NSEGR.Assembly.GaussianGluingLaw.congr
#check @NSEGR.Assembly.GaussianGluingLaw.translate
#print axioms NSEGR.Assembly.GaussianGluingLaw.translate
#check @NSEGR.Assembly.gaussianGluingLaw_germ_of_literature
#print axioms NSEGR.Assembly.gaussianGluingLaw_germ_of_literature
#check @NSEGR.Assembly.literatureGaussianGerm_of_gluingLaw
#print axioms NSEGR.Assembly.literatureGaussianGerm_of_gluingLaw
#check @NSEGR.Assembly.lorentzian_of_gaussianGluingLaw
#print axioms NSEGR.Assembly.lorentzian_of_gaussianGluingLaw
#check @NSEGR.Assembly.radialExtensionResult_of_literatureGaussian
#print axioms NSEGR.Assembly.radialExtensionResult_of_literatureGaussian
#check @NSEGR.Assembly.analyticRadialExtensionLaws_of_literatureGaussian
#print axioms NSEGR.Assembly.analyticRadialExtensionLaws_of_literatureGaussian

NSE_GR_SOURCE_EXPORT
WINDOWS_ENTRYPOINT = GR_adapter\run.cmd
LINUX_ENTRYPOINT = bash GR_adapter/run.sh
REQUIRED_EXTERNAL_TOOLS = native Lean 4.34.0-rc1; Git; Python >= 3.9
LAYOUT = GR_adapter + Auxillary/GR sibling directories
CHECKOUT_OF_WINDOWS_INCOMPATIBLE_REPOSITORY_DIRECTORIES = NOT_REQUIRED
DEPENDENCIES = exact GR_adapter/lake-manifest.json revisions
DEPENDENCY_SOURCE_POINTERS = GR_adapter/DEPENDENCY_SOURCE_POINTERS.json
CACHES = preserve compatible external native caches; never clean
SOURCE_COMMIT_METADATA = caller-declared; file bytes separately SHA256-indexed
STATUS = source export; no new compiler or theorem-audit evidence
ADMISSION_PREMISES = unchanged; read Auxillary/GR/formalization-status.json

@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  python run.py --external-native-windows %*
) else (
  py -3 run.py --external-native-windows %*
)
exit /b %errorlevel%
